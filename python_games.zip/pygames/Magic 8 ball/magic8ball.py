import random

print("Welcome to MAGIC 8 BALL!!")


answers = ['It is certain','It is decidedly so','Without a doubt','Yes, definitely','You may rely on it','As I see it, yes','Most likely','Outlook good','Yes','Signs point to yes',
            'Reply hazy try again','Ask again later','Better not tell you now','Cannot predict now','Concentrate and ask again',"Don't count on it",'My reply is no','My sources say no',
            'Outlook not so good','Very doubtful']
def replay():
    print("Do you want to try again? Y/N")
    reply = input()
    if reply == 'Y':
        magic()
    elif reply == 'N':
        quit()
    else:
        print("404 Error!!, Try again")
        replay()
def magic():    
    print("What is your name: ")
    name = input()
    print("Hello " + name +",")
    input("Enter a question you want to ask? ")
    print(answers[random.randint(0, len(answers)-1)])
    replay()
magic()

