
print("Welcome to an adventure game!!")
name = input("Enter your name: ")
print("Hello ", name, "would you like to play?? [Y/N]")
reply = input()
if reply == "Y":
    answer = input("You reach a crossroads, would you like to take the left or right? (left/right)")

    if answer == "left":
        answer = input("You encounter a monster, would you like to run or attack? (run/attack)")

        if answer == "attack":
            print("That was not the greatest idea, you lost!")
        else:
            print("Good choice, you made it away safely.")
            answer = input("You see a car and a plane. Which would you like to take? (car/plane)")

            if answer == "plane":
                print("Unfortunately you do not know how to fly a plane. you crash into a volcano and die.... GAME OVER!!")
            else:
                print("You Won!!")

    elif answer == "right":
        print("You walk aimlessly to the right and fall off a cliff and die!!...YOU LOST")
    else:
        print("Invalid choice, you lost!!")
else:
    quit()


        

    
      
