import pgzrun
from random import randint
import time

WIDTH = 800
HEIGHT = 600
CENTER_X = WIDTH / 2
CENTER_Y = HEIGHT / 2
game_over = False
finalized = False
garden_happy = True
wildflower_collision = False
time_elapsed = 0
start_time = time.time()

man = Actor("man")
man.pos = 100, 500
flower_list = []
wilted_list = []
wildflower_list = []
wildflower_vy_list = []
wildflower_vx_list = []

def draw():
    global game_over, time_elapsed, finalized
    if not game_over:
        screen.clear()
        screen.blit("garden", (0, 0))
        man.draw()
        for flower in flower_list:
            flower.draw()
        for wildflower in wildflower_list:
            wildflower.draw()
        time_elapsed = int(time.time() - start_time)
        screen.draw.text("Garden happy for: " + str(time_elapsed) + " seconds", topleft=(10, 10), color="black")
    else:
        if not finalized:
            man.draw()
            screen.draw.text("Garden happy for: " +str(time_elapsed) + " seconds", topleft=(10, 10), color="black")
            if (not garden_happy):
                screen.draw.text("GARDEN UNHAPPY—GAME OVER!", color="black",topleft=(10, 50))
                finalized = True
            else:
                screen.draw.text("WILDFLOWER ATTACK-GAME OVER!!", color="black", topleft = (10,50))
                finalized = True
    return
                                 

def new_flower():
    global flower_list, wilted_list
    flower_new = Actor("flower")
    flower_new.pos = randint(50, WIDTH - 50), randint(150, HEIGHT - 100)
    flower_list.append(flower_new)
    wilted_list.append("happy")
    return

def add_flowers():
    global game_over
    if not game_over:
        new_flower()
        clock.schedule(add_flowers, 4)
    return

def check_wilt_times():
    global wilted_list, game_over, garden_happy
    if wilted_list:
        for wilted_since in wilted_list:
            if (not wilted_since == "happy"):
                time_wilted = int(time.time() - wilted_since)
                if (time_wilted) > 10.0:
                    garden_happy = False
                    game_over = True
                    break
    return

def wilt_flower():
    global flower_list, wilted_list, game_over
    if not game_over:
        if flower_list:
            rand_flower = randint(0, len(flower_list) - 1)
            if (flower_list[rand_flower].image == "flower"):
                flower_list[rand_flower].image = "flower-wilt"
                wilted_list[rand_flower] = time.time()
        clock.schedule(wilt_flower, 3)
    return

def check_flower_collision():
    global man, flower_list, wilted_list
    index = 0
    for flower in flower_list:
        if (flower.colliderect(man) and
                flower.image == "flower-wilt"):
            flower.image = "flower"
            wilted_list[index] = "happy"
            break
        index = index + 1
    return

def check_wildflower_collision():
    global man, wildflower_list, wildflower_collision
    global game_over
    for wildflower in wildflower_list:
        if wildflower.colliderect(man):
            man.image = "zap"
            game_over = True
            break
    return

def velocity():
    random_dir = randint(0, 1)
    random_velocity = randint(2, 3)
    if random_dir == 0:
        return -random_velocity
    else:
        return random_velocity

def mutate():
    global flower_list, wildflower_list, wildflower_vy_list
    global wildflower_vx_list, game_over
    if not game_over and flower_list:
        rand_flower = randint(0, len(flower_list) - 1)
        wildflower_pos_x = flower_list[rand_flower].x
        wildflower_pos_y = flower_list[rand_flower].y
        del flower_list[rand_flower]
        wildflower = Actor("wildflower")
        wildflower.pos = wildflower_pos_x, wildflower_pos_y
        wildflower_vx = velocity()
        wildflower_vy = velocity()
        wildflower = wildflower_list.append(wildflower)
        wildflower_vx_list.append(wildflower_vx)
        wildflower_vy_list.append(wildflower_vy)
        clock.schedule(mutate, 20)
    return

def update_wildflowers():
    global wildflower_list, game_over
    if not game_over:
        index = 0
        for wildflower in wildflower_list:
            wildflower_vx = wildflower_vx_list[index]
            wildflower_vy = wildflower_vy_list[index]
            wildflower.x = wildflower.x + wildflower_vx
            wildflower.y = wildflower.y + wildflower_vy
            if wildflower.left < 0:
                wildflower_vx_list[index] = -wildflower_vx
            if wildflower.right > WIDTH:
                wildflower_vx_list[index] = -wildflower_vx
            if wildflower.top < 150:
               wildflower_vy_list[index] = -wildflower_vy
            if wildflower.bottom > HEIGHT:
               wildflower_vy_list[index] = -wildflower_vy
            index = index + 1
    return

def reset_man():
    global game_over
    if not game_over:
        man.image = "man"
    return

add_flowers()
wilt_flower()

def update():
    global score, game_over, wildflower_collision
    global flower_list, wildflower_list, time_elapsed
    wild_flower_collision = check_wildflower_collision()
    check_wilt_times()
    if not game_over:
        if keyboard.space:
            man.image = "man-water"
            clock.schedule(reset_man, 0.5)
            check_flower_collision()
        if keyboard.left and man.x > 0:
            man.x -= 5
        elif keyboard.right and man.x < WIDTH:
            man.x += 5
        elif keyboard.up and man.y > 150:
            man.y -= 5
        elif keyboard.down and man.y < HEIGHT:
            man.y += 5
        if time_elapsed > 15 and not wildflower_list:
            mutate()
        update_wildflowers()


pgzrun.go()
        
