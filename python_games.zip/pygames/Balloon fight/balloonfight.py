import pgzrun
from random import randint

FONT_COLOR = (255, 255, 255)
WIDTH = 800
HEIGHT = 600
CENTER_X = WIDTH / 2
CENTER_Y = HEIGHT / 2
CENTER = (CENTER_X, CENTER_Y)
balloon = Actor("balloon")
balloon.pos = 400,300
house = Actor("house")
house.pos = randint(800, 1600),460
knife = Actor("knife")
knife.pos = randint(800,1600), randint(10,400)

up = False
game_over = False
score = 0

def draw():
    screen.blit("background", (0, 0))
    if not game_over:
        balloon.draw()
        knife.draw()
        house.draw()
        screen.draw.text("Score: " + str(score), (700, 5), color = "black")
    else:
        display_message("GAME OVER!!", "Try again.")
        

def on_key_down():
    global up
    up = True
    balloon.y -= 30

def on_key_up():
    global up
    up = False
        
def update():
    global game_over, score
    if not game_over:
        if not up:
            balloon.y +=1
        if knife.x > 0:
            knife.x -= 10
        else:
            knife.x = randint(800,1600)
            knife.y = randint(10,200)
            score +=1
        if house.right > 0:
            house.x -= 8
        else:
            house.x = randint(800, 1600)
            score += 1
        if balloon.top < 0 or balloon.bottom > 560:
            game_over = True

        if balloon.collidepoint(knife.x, knife.y):
            game_over = True
            
        if balloon.collidepoint(house.x, house.y):
            game_over = True

def display_message(heading_text, sub_heading_text):
    screen.draw.text(heading_text, fontsize=60, center=CENTER, color=FONT_COLOR)
    screen.draw.text(sub_heading_text, fontsize=30, center=(CENTER_X, CENTER_Y + 30), color=FONT_COLOR)

pgzrun.go()
